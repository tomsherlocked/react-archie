import React from "react";
function DoneState(props) {
  return <div className="card-complete">Event logged, thanks!</div>;
}

export default DoneState;
