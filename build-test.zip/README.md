# React/Archie stuff

### Colour pallete

https://coolors.co/282c34-72a98f-3581b8-f5c396-eae8ff

### .env structure

- Hooking up to the node-RED instance

```bash
SKIP_PREFLIGHT_CHECK=true
BASE_ROUTE = "<base-route>"
TOILET="<route>"
WEIGHT="<other route>"
```
